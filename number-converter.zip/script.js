// switch(optionFrom) {
//     case 'BINARY':
//         for(let i = 0; i < inputFrom.value.length; i++) {
//             if(inputFrom.value[i] !== 0 || inputFrom.value[i] !== 1){
//                 window.alert('Input may contain only 0 or 1 numbers!')
//             }
//         }
//     break;
//     case 'ROMAN':
//         const letters = /^[A-Za-z]+$/;
//         if(inputFrom.value.match(letters)){
//                 return true;
//             }
//         else {
//             window.alert('Input may contain only letters!')
//             return false;
//             }
// }
